<div class="container about-container">
        <div class="about-content">
            <h2>Acerca de Nosotros</h2>
            <p>Bienvenido a Reserva Mesas, tu destino número uno para reservar mesas en los mejores restaurantes de la ciudad. Nuestro objetivo es ofrecerte una experiencia de reserva fácil y rápida, permitiéndote encontrar y reservar la mesa perfecta para cualquier ocasión.</p>
            <p>En Reserva Mesas, nos apasiona la buena comida y el excelente servicio al cliente. Estamos aquí para asegurarnos de que cada una de tus reservas sea una experiencia agradable y sin estrés.</p>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</div>
