<?php

const APP_URL="http://localhost/pry_reserva_restaurante/";
const APP_NAME="Reserva Restaurant";
const APP_SESSION_NAME="Restaurant";

date_default_timezone_set("America/Mexico_City");